The description of the files

Covid-19 has had a significant impact on the financial, family and work experience of Melbourne residents in 2020. To understand the impact of the 2020 changes, 
researchers surveyed 1000 Melbourne residents to look at data from their differences in experience in mental health, financial stability and family life in 2019 and 2020.
The folder consists of two files, survey_data and codebook, survey_data is a file after anti-identification, codebook is the corresponding variable interpretation and
 the corresponding anti-recognition method.
In the case of average income, excluding average income, the average income is 3106.
The files include these:
- income_expected：What is your expected household income for 2021?
- age：How old are you?
- family_member：Number of children/number of adults
- postcode
- frequency： how often do you work from home?
- work_per_week：how many hours per week do you work？
- work_schedule：How stable is your work schedule？
- mental_health：What best describes your mental health？
- income：What's your household income？
- Year
- work time：when would you typically work?
- homelife：When you think about your home life？



The description of the origin data
The data set for this exercise contains the following variables:
- id_number
- StartDate
- Finished
- Progress
- Duration
- EndDate
- RecordedDate
- ResponseID
- ResponseLastName
- ResponseFirstName
- LocationLatitude
- LocationLongitude
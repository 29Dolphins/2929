# ETC5513_2020
Template and materials for ETC5513  Collaborative and Reproducible Practices
Author: Patricia Menéndez

# License

All the contents of this course are under the "CC BY-NC-ND" Creative Commons license , visit https://creativecommons.org/licenses/by-nc-sa/4.0/.




# Several photos for the slides where source from 
 https://unsplash.com/
 
 Acknowledgment to the authors is as follow:
 
 **W1**
 - william-iven-gcsNOsPEXfs-unsplash
 - helloquence-5fNmWej4tAA-unsplash
 - baim-hanif-pYWuOMhtc6k-unsplash.
 
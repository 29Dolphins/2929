ETC5513-Assignment4 

## Topic

Welcome to our group assignment for ETC5513. The topic we have chosen is "exploring the relationship between GDP and its relevant factors". We first explore each variable separately and gain insight into the relationship of variables. Based on that, we use modelling to explain the potential relationship we observed. 

## Reproducibility 
This report is fully reproducible. Our repository comes with a reference file named 'reference. bib, a 'Figures' Folder and a 'Data' folder. All these files are necessary for reproducibility.

## Group members
Peichen Zhao, Xinyi Tang and Hao Li